# Bron — бронирование залов и транспорта

Курсовая: веб-приложение для бронирования конференц-залов и транспорта.

**Структура (компактно):**
- **server** — сервер (Node.js, Express): `index.js`, `api.js`, `baza.js`, `data.json`
- **site** — сайт (Vue 3, Vite): в `src` — `main.js`, `App.vue`, `router.js`, `api.js`, `style.css`, папка **pages**
- **site/public/images** — фото залов (`rooms`) и транспорта (`transport`)

**Запуск:** из корня выполнить `npm run dev` или двойной клик по `start.bat`.  
Сервер: http://localhost:4000, сайт: http://localhost:5174

**После клона с GitHub на другом компьютере:**  
Установить Node.js (LTS), в папке проекта выполнить `npm run install:all`, затем `npm run dev` (или сразу `npm start` — установит зависимости и запустит приложение). Никаких дополнительных настроек не требуется.

**Если папка без node_modules (компактная копия):**  
В корне выполнить `npm run install:all`, затем `npm run dev`. Либо по отдельности: `npm install`, в `server` и в `site` — `npm install`.

**Админ:** при регистрации код `ADMIN-INVITE-2026`.
