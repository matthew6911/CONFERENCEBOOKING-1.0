@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo [Bron] Установка зависимостей...
call npm run install:all
if errorlevel 1 (
  echo [Bron] Ошибка установки. Проверьте, что установлен Node.js: https://nodejs.org
  pause
  exit /b 1
)

echo.
echo [Bron] Запуск сервера и сайта...
echo   Сервер:  http://localhost:4000
echo   Сайт:    http://localhost:5174
echo.
call npm run dev

pause
