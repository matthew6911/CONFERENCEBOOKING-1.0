import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.join(__dirname, "data.json");

let data = { users: [], rooms: [], transport: [], bookings: [], transportBookings: [] };

function load() {
  try {
    const raw = fs.readFileSync(DATA_FILE, "utf8");
    const parsed = JSON.parse(raw);
    data.users = parsed.users || [];
    data.rooms = parsed.rooms || [];
    data.transport = parsed.transport || [];
    data.bookings = parsed.bookings || [];
    data.transportBookings = parsed.transportBookings || [];
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
  }
}

function save() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf8");
}

function nextId(collection) {
  const arr = data[collection];
  return arr.length ? Math.max(...arr.map((x) => x.id)) + 1 : 1;
}

function toDate(val) {
  return val instanceof Date ? val : typeof val === "string" ? new Date(val) : val;
}

export function findUserByEmail(email) {
  return data.users.find((u) => u.email === email) || null;
}

export function findUserById(id) {
  return data.users.find((u) => u.id === id) || null;
}

export function createUser({ email, passwordHash, fullName, role }) {
  const user = { id: nextId("users"), email, passwordHash, fullName, role: role || "USER", createdAt: new Date().toISOString() };
  data.users.push(user);
  save();
  return user;
}

export function updateUserRole(id, role) {
  const i = data.users.findIndex((u) => u.id === id);
  if (i === -1) return null;
  data.users[i].role = role;
  save();
  return data.users[i];
}

export function deleteUser(id) {
  data.bookings = data.bookings.filter((b) => b.userId !== id);
  data.transportBookings = data.transportBookings.filter((b) => b.userId !== id);
  const i = data.users.findIndex((u) => u.id === id);
  if (i === -1) return false;
  data.users.splice(i, 1);
  save();
  return true;
}

export function getAllUsers() {
  return [...data.users].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

export function getRooms() {
  return [...data.rooms].sort((a, b) => a.name.localeCompare(b.name));
}

export function findRoomById(id) {
  return data.rooms.find((r) => r.id === id) || null;
}

export function createRoom(room) {
  const r = {
    id: nextId("rooms"),
    name: room.name,
    location: room.location,
    capacity: room.capacity,
    description: room.description ?? null,
    pricePerHour: room.pricePerHour ?? null,
    tags: Array.isArray(room.tags) ? room.tags : [],
    imageUrls: Array.isArray(room.imageUrls) ? room.imageUrls : [],
    createdAt: new Date().toISOString(),
  };
  data.rooms.push(r);
  save();
  return r;
}

export function updateRoom(id, updates) {
  const i = data.rooms.findIndex((r) => r.id === id);
  if (i === -1) return null;
  const r = data.rooms[i];
  if (updates.name !== undefined) r.name = updates.name;
  if (updates.location !== undefined) r.location = updates.location;
  if (updates.capacity !== undefined) r.capacity = updates.capacity;
  if (updates.description !== undefined) r.description = updates.description;
  if (updates.pricePerHour !== undefined) r.pricePerHour = updates.pricePerHour;
  if (updates.tags !== undefined) r.tags = Array.isArray(updates.tags) ? updates.tags : [];
  if (updates.imageUrls !== undefined) r.imageUrls = Array.isArray(updates.imageUrls) ? updates.imageUrls : [];
  save();
  return r;
}

export function deleteRoom(id) {
  data.bookings = data.bookings.filter((b) => b.roomId !== id);
  const i = data.rooms.findIndex((r) => r.id === id);
  if (i === -1) return false;
  data.rooms.splice(i, 1);
  save();
  return true;
}

export function getTransport() {
  return [...data.transport].sort((a, b) => a.name.localeCompare(b.name));
}

export function findTransportById(id) {
  return data.transport.find((t) => t.id === id) || null;
}

export function createTransport(transport) {
  const t = {
    id: nextId("transport"),
    name: transport.name,
    type: transport.type,
    seats: transport.seats,
    description: transport.description ?? null,
    pricePerHour: transport.pricePerHour ?? null,
    imageUrls: Array.isArray(transport.imageUrls) ? transport.imageUrls : [],
    createdAt: new Date().toISOString(),
  };
  data.transport.push(t);
  save();
  return t;
}

export function updateTransport(id, updates) {
  const i = data.transport.findIndex((t) => t.id === id);
  if (i === -1) return null;
  const t = data.transport[i];
  if (updates.name !== undefined) t.name = updates.name;
  if (updates.type !== undefined) t.type = updates.type;
  if (updates.seats !== undefined) t.seats = updates.seats;
  if (updates.description !== undefined) t.description = updates.description;
  if (updates.pricePerHour !== undefined) t.pricePerHour = updates.pricePerHour;
  if (updates.imageUrls !== undefined) t.imageUrls = Array.isArray(updates.imageUrls) ? updates.imageUrls : [];
  save();
  return t;
}

export function deleteTransport(id) {
  data.transportBookings = data.transportBookings.filter((b) => b.transportId !== id);
  const i = data.transport.findIndex((t) => t.id === id);
  if (i === -1) return false;
  data.transport.splice(i, 1);
  save();
  return true;
}

export function getBookingsByUserId(userId) {
  const roomBookings = data.bookings
    .filter((b) => b.userId === userId)
    .map((b) => ({ ...b, room: findRoomById(b.roomId) }))
    .filter((b) => b.room)
    .sort((a, b) => new Date(b.startTime) - new Date(a.startTime));
  const transportBookings = data.transportBookings
    .filter((b) => b.userId === userId)
    .map((b) => ({ ...b, transport: findTransportById(b.transportId) }))
    .filter((b) => b.transport)
    .sort((a, b) => new Date(b.startTime) - new Date(a.startTime));
  return { roomBookings, transportBookings };
}

export function createRoomBooking({ userId, roomId, title, startTime, endTime, attendees }) {
  const b = { id: nextId("bookings"), userId, roomId, title, startTime: toDate(startTime).toISOString(), endTime: toDate(endTime).toISOString(), attendees, createdAt: new Date().toISOString() };
  data.bookings.push(b);
  save();
  return b;
}

export function createTransportBooking({ userId, transportId, startTime, endTime, seatsBooked }) {
  const b = { id: nextId("transportBookings"), userId, transportId, startTime: toDate(startTime).toISOString(), endTime: toDate(endTime).toISOString(), seatsBooked, createdAt: new Date().toISOString() };
  data.transportBookings.push(b);
  save();
  return b;
}

export function findRoomBookingById(id) {
  return data.bookings.find((b) => b.id === id) || null;
}

export function findTransportBookingById(id) {
  return data.transportBookings.find((b) => b.id === id) || null;
}

export function deleteRoomBooking(id) {
  const i = data.bookings.findIndex((b) => b.id === id);
  if (i === -1) return false;
  data.bookings.splice(i, 1);
  save();
  return true;
}

export function deleteTransportBooking(id) {
  const i = data.transportBookings.findIndex((b) => b.id === id);
  if (i === -1) return false;
  data.transportBookings.splice(i, 1);
  save();
  return true;
}

export function findOverlappingRoomBooking(roomId, start, end) {
  const s = toDate(start).getTime();
  const e = toDate(end).getTime();
  return data.bookings.find((b) => b.roomId === roomId && new Date(b.startTime).getTime() < e && new Date(b.endTime).getTime() > s) || null;
}

export function findOverlappingTransportBookings(transportId, start, end) {
  const s = toDate(start).getTime();
  const e = toDate(end).getTime();
  return data.transportBookings.filter((b) => b.transportId === transportId && new Date(b.startTime).getTime() < e && new Date(b.endTime).getTime() > s);
}

export function countAdmins() {
  return data.users.filter((u) => u.role === "ADMIN").length;
}

export function initStore() {
  load();
}

const seedRooms = [
  { name: 'LOFT "Авиатор"', location: "Москва, м. Сухаревская", capacity: 60, description: "LOFT «Авиатор» — многофункциональное пространство формата лофт. Подходит для презентаций, стратегических сессий и неформальных встреч до 60 гостей. В зале предусмотрена зона для докладчика и комфортная рассадка участников.", imageUrls: ["https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=1600&q=80"] },
  { name: "Конференц-зал Skyline", location: "Москва-Сити, башня Империя", capacity: 120, description: "Конференц-зал Skyline — классический конференц-зал с рядной рассадкой, столом спикеров и проекционным оборудованием. Оптимален для конференций, лекций и презентаций до 120 человек.", imageUrls: ["https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?w=1600&q=80"] },
  { name: 'Бизнес-зал "Невский"', location: "Санкт-Петербург, Невский проспект", capacity: 40, description: "Бизнес-зал «Невский» — камерный зал для деловых встреч и обучающих мероприятий до 40 участников. Формат подходит для совещаний, тренингов и работы небольших команд.", imageUrls: ["https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=1600&q=80"] },
  { name: "Workshop Hub", location: "Москва, творческий кластер", capacity: 30, description: "Workshop Hub — универсальное пространство для воркшопов и тренингов до 30 человек. В зале можно организовать как рядную, так и групповую рассадку для работы в командах.", imageUrls: ["https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=1600&q=80"] },
  { name: "Event Hall Atrium", location: "Бизнес-центр Atrium, Москва", capacity: 200, description: "Event Hall Atrium — просторный зал для крупных мероприятий до 200 гостей. Подходит для конференций, презентаций и корпоративных событий с центральной сценой и большой аудиторией.", imageUrls: ["https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1600&q=80"] },
  { name: "Studio Stage", location: "Креативный квартал, Москва", capacity: 80, description: "Studio Stage — зал формата студии для презентаций и творческих мероприятий до 80 человек. Подойдёт для запусков продуктов, внутренних мероприятий и камерных показов.", imageUrls: ["https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1600&q=80"] },
  { name: "Press Center", location: "Конгресс-центр, Москва", capacity: 90, description: "Press Center — зал для пресс-конференций, публичных заявлений и брифингов до 90 человек. Есть зона для спикеров и площадка для размещения гостей и представителей СМИ.", imageUrls: ["https://images.unsplash.com/photo-1522199710521-72d69614c702?w=1600&q=80"] },
  { name: "Boardroom Prime", location: "Бизнес-центр класса A, Москва-Сити", capacity: 20, description: "Boardroom Prime — переговорная для встреч топ-менеджмента и ключевых партнёрских переговоров. Рассчитана до 20 участников, удобна для длительных деловых сессий и подписания соглашений.", imageUrls: ["https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?w=1600&q=80"] },
];

const seedTransport = [
  { name: "Mercedes Sprinter", type: "Микроавтобус", seats: 18, description: "VIP-трансфер." },
  { name: "Business Sedan Fleet", type: "Седаны E-class", seats: 3, description: "С водителями." },
  { name: "Shuttle Bus", type: "Автобус", seats: 45, description: "Подвоз гостей." },
  { name: "Cargo Truck", type: "Грузовик", seats: 2, description: "Оборудование." },
];

export function seedIfEmpty() {
  if (data.rooms.length === 0) seedRooms.forEach((r) => createRoom({ ...r, tags: [] }));
  if (data.transport.length === 0) seedTransport.forEach((t) => createTransport(t));
}
