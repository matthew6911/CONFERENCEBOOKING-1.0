import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import api from "./api.js";
import * as baza from "./baza.js";

dotenv.config();
baza.initStore();
baza.seedIfEmpty();

const app = express();
const PORT = process.env.PORT || 4000;
const origins = [process.env.FRONTEND_URL || "http://localhost:5174", "http://localhost:5173", "http://127.0.0.1:5174", "http://127.0.0.1:5173"];

app.use(cors({ origin: (origin, cb) => cb(null, !origin || origins.includes(origin)), credentials: true }));
app.use(express.json());

app.get("/api/health", (req, res) => res.json({ status: "ok" }));
app.use("/api", api);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Ошибка сервера" });
});

app.listen(PORT, () => console.log("Сервер на порту", PORT));
