import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { z } from "zod";
import * as baza from "./baza.js";

const accessSecret = process.env.JWT_ACCESS_SECRET || "dev_access_secret";
const refreshSecret = process.env.JWT_REFRESH_SECRET || "dev_refresh_secret";

export function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) return res.status(401).json({ error: "Требуется авторизация" });
  try {
    const payload = jwt.verify(authHeader.substring(7), accessSecret);
    req.user = { userId: payload.userId, role: payload.role };
    next();
  } catch {
    res.status(401).json({ error: "Недействительный токен" });
  }
}

export function requireAdmin(req, res, next) {
  if (!req.user) return res.status(401).json({ error: "Требуется авторизация" });
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Доступ запрещён" });
  next();
}

function createTokens(payload) {
  return {
    accessToken: jwt.sign(payload, accessSecret, { expiresIn: "30m" }),
    refreshToken: jwt.sign(payload, refreshSecret, { expiresIn: "14d" }),
  };
}

const api = Router();

// ——— Авторизация ———
api.post("/auth/register", async (req, res) => {
  const parse = z.object({ email: z.string().email(), password: z.string().min(6), fullName: z.string().min(2), inviteAdminCode: z.string().optional() }).safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Неверные данные" });
  const { email, password, fullName, inviteAdminCode } = parse.data;
  if (baza.findUserByEmail(email)) return res.status(400).json({ error: "Пользователь с таким email уже есть" });
  const passwordHash = await bcrypt.hash(password, 10);
  const role = inviteAdminCode === "ADMIN-INVITE-2026" ? "ADMIN" : "USER";
  const user = baza.createUser({ email, passwordHash, fullName, role });
  const tokens = createTokens({ userId: user.id, role: user.role });
  res.status(201).json({ user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role }, ...tokens });
});

api.post("/auth/login", async (req, res) => {
  const parse = z.object({ email: z.string().email(), password: z.string() }).safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Неверные данные" });
  const { email, password } = parse.data;
  const user = baza.findUserByEmail(email);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) return res.status(400).json({ error: "Неверный email или пароль" });
  const tokens = createTokens({ userId: user.id, role: user.role });
  res.json({ user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role }, ...tokens });
});

api.post("/auth/refresh", async (req, res) => {
  const refreshToken = req.body?.refreshToken;
  if (!refreshToken) return res.status(400).json({ error: "Нет токена" });
  try {
    const payload = jwt.verify(refreshToken, refreshSecret);
    res.json(createTokens({ userId: payload.userId, role: payload.role }));
  } catch {
    res.status(401).json({ error: "Недействительный токен" });
  }
});

// ——— Залы ———
const roomSchema = z.object({ name: z.string().min(2), location: z.string().min(2), capacity: z.number().int().positive(), description: z.string().optional(), pricePerHour: z.number().int().min(0).optional(), tags: z.array(z.string()).optional(), imageUrls: z.array(z.string()).optional() });

api.get("/rooms", requireAuth, (req, res) => res.json(baza.getRooms()));
api.post("/rooms", requireAuth, requireAdmin, (req, res) => {
  const parse = roomSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Неверные данные" });
  res.status(201).json(baza.createRoom(parse.data));
});
api.put("/rooms/:id", requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Неверный id" });
  const parse = roomSchema.partial().safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Неверные данные" });
  const ok = baza.updateRoom(id, parse.data);
  if (!ok) return res.status(404).json({ error: "Зал не найден" });
  res.json(ok);
});
api.delete("/rooms/:id", requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Неверный id" });
  if (!baza.deleteRoom(id)) return res.status(404).json({ error: "Зал не найден" });
  res.status(204).end();
});

// ——— Транспорт ———
const transportSchema = z.object({ name: z.string().min(2), type: z.string().min(2), seats: z.number().int().positive(), description: z.string().optional(), pricePerHour: z.number().int().min(0).optional(), imageUrls: z.array(z.string()).optional() });

api.get("/transport", requireAuth, (req, res) => res.json(baza.getTransport()));
api.post("/transport", requireAuth, requireAdmin, (req, res) => {
  const parse = transportSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Неверные данные" });
  res.status(201).json(baza.createTransport(parse.data));
});
api.put("/transport/:id", requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Неверный id" });
  const parse = transportSchema.partial().safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Неверные данные" });
  const ok = baza.updateTransport(id, parse.data);
  if (!ok) return res.status(404).json({ error: "Транспорт не найден" });
  res.json(ok);
});
api.delete("/transport/:id", requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Неверный id" });
  if (!baza.deleteTransport(id)) return res.status(404).json({ error: "Транспорт не найден" });
  res.status(204).end();
});

// ——— Бронирования ———
const roomBookingSchema = z.object({ roomId: z.coerce.number().int().positive(), title: z.string().min(1), startTime: z.string().min(1), endTime: z.string().min(1), attendees: z.coerce.number().int().positive() });
const transportBookingSchema = z.object({ transportId: z.coerce.number().int().positive(), startTime: z.string().min(1), endTime: z.string().min(1), seatsBooked: z.coerce.number().int().positive() });

api.get("/bookings/me", requireAuth, (req, res) => res.json(baza.getBookingsByUserId(req.user.userId)));

api.post("/bookings/rooms", requireAuth, (req, res) => {
  const parse = roomBookingSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Неверные данные" });
  const { roomId, title, startTime, endTime, attendees } = parse.data;
  const room = baza.findRoomById(roomId);
  if (!room) return res.status(404).json({ error: "Зал не найден" });
  if (attendees > room.capacity) return res.status(400).json({ error: "Превышена вместимость" });
  const start = new Date(startTime);
  const end = new Date(endTime);
  if (end <= start) return res.status(400).json({ error: "Время окончания должно быть позже начала" });
  if (baza.findOverlappingRoomBooking(roomId, start, end)) return res.status(409).json({ error: "Зал занят на это время" });
  res.status(201).json(baza.createRoomBooking({ userId: req.user.userId, roomId, title, startTime: start, endTime: end, attendees }));
});

api.post("/bookings/transport", requireAuth, (req, res) => {
  if (!req.body || typeof req.body !== "object") return res.status(400).json({ error: "Нужен JSON: transportId, startTime, endTime, seatsBooked" });
  const parse = transportBookingSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: parse.error.errors?.map((e) => e.path.join(".") + ": " + e.message).join("; ") || "Неверные данные" });
  const { transportId, startTime, endTime, seatsBooked } = parse.data;
  const transport = baza.findTransportById(transportId);
  if (!transport) return res.status(404).json({ error: "Транспорт не найден" });
  if (seatsBooked > transport.seats) return res.status(400).json({ error: "Превышено кол-во мест" });
  const start = new Date(startTime);
  const end = new Date(endTime);
  if (end <= start) return res.status(400).json({ error: "Время окончания должно быть позже начала" });
  const overlapping = baza.findOverlappingTransportBookings(transportId, start, end);
  const used = overlapping.reduce((s, t) => s + t.seatsBooked, 0);
  if (used + seatsBooked > transport.seats) return res.status(409).json({ error: "Недостаточно мест на это время" });
  res.status(201).json(baza.createTransportBooking({ userId: req.user.userId, transportId, startTime: start, endTime: end, seatsBooked }));
});

api.delete("/bookings/rooms/:id", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Неверный id" });
  const b = baza.findRoomBookingById(id);
  if (!b || b.userId !== req.user.userId) return res.status(404).json({ error: "Бронирование не найдено" });
  baza.deleteRoomBooking(id);
  res.status(204).end();
});

api.delete("/bookings/transport/:id", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Неверный id" });
  const b = baza.findTransportBookingById(id);
  if (!b || b.userId !== req.user.userId) return res.status(404).json({ error: "Бронирование не найдено" });
  baza.deleteTransportBooking(id);
  res.status(204).end();
});

// ——— Админ: пользователи ———
api.get("/admin/users", requireAuth, requireAdmin, (req, res) => {
  res.json(baza.getAllUsers().map((u) => ({ id: u.id, email: u.email, fullName: u.fullName, role: u.role, createdAt: u.createdAt })));
});
api.patch("/admin/users/:id", requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Неверный id" });
  const parse = z.object({ role: z.enum(["USER", "ADMIN"]) }).safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Неверные данные" });
  if (id === req.user.userId && parse.data.role === "USER" && baza.countAdmins() <= 1) return res.status(400).json({ error: "Должен остаться хотя бы один админ" });
  const user = baza.updateUserRole(id, parse.data.role);
  if (!user) return res.status(404).json({ error: "Пользователь не найден" });
  res.json({ id: user.id, email: user.email, fullName: user.fullName, role: user.role, createdAt: user.createdAt });
});
api.delete("/admin/users/:id", requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Неверный id" });
  if (id === req.user.userId) return res.status(400).json({ error: "Нельзя удалить себя" });
  if (!baza.deleteUser(id)) return res.status(404).json({ error: "Пользователь не найден" });
  res.status(204).end();
});

export default api;
