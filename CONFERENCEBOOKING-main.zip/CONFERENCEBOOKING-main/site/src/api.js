const API_BASE = import.meta.env.VITE_API_BASE_URL || "/api";
const STORAGE_KEY = "conference_booking_auth";

let accessToken = null;
let refreshToken = null;
let user = null;
let onAuthChange = () => {};

function loadFromStorage() {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const data = JSON.parse(raw);
    accessToken = data.accessToken || null;
    refreshToken = data.refreshToken || null;
    user = data.user || null;
  } catch (_) {}
}

function saveToStorage() {
  if (accessToken && refreshToken) {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify({ accessToken, refreshToken, user }));
  } else {
    sessionStorage.removeItem(STORAGE_KEY);
  }
  onAuthChange();
}

loadFromStorage();

export function setTokens(access, refresh, userData) {
  accessToken = access;
  refreshToken = refresh;
  if (userData) user = userData;
  saveToStorage();
  onAuthChange();
}

export function clearTokens() {
  accessToken = null;
  refreshToken = null;
  user = null;
  saveToStorage();
  onAuthChange();
}

export function getUser() {
  return user;
}

export function setUser(userData) {
  user = userData;
  if (accessToken) saveToStorage();
  onAuthChange();
}

export function setOnAuthChange(cb) {
  onAuthChange = cb;
}

export function getAccessToken() {
  return accessToken;
}

export function isAuthenticated() {
  return !!accessToken;
}

async function refreshAccessToken() {
  if (!refreshToken) return false;
  const res = await fetch(`${API_BASE}/auth/refresh`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refreshToken }),
  });
  if (!res.ok) return false;
  const data = await res.json();
  accessToken = data.accessToken;
  if (data.refreshToken) refreshToken = data.refreshToken;
  saveToStorage();
  return true;
}

export async function api(url, options = {}) {
  const fullUrl = url.startsWith("http") ? url : `${API_BASE}${url.startsWith("/") ? "" : "/"}${url}`;
  const headers = { ...options.headers };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;

  let res = await fetch(fullUrl, { ...options, headers, credentials: "include" });

  if (res.status === 401 && refreshToken) {
    const refreshed = await refreshAccessToken();
    if (refreshed) {
      headers.Authorization = `Bearer ${accessToken}`;
      res = await fetch(fullUrl, { ...options, headers, credentials: "include" });
    }
  }

  return res;
}

export async function apiJson(url, options = {}) {
  const res = await api(url, { ...options, headers: { "Content-Type": "application/json", ...options.headers } });
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch (_) {
    data = { error: text || "Ошибка ответа сервера" };
  }
  if (!res.ok) {
    const err = new Error(data?.error || `Ошибка ${res.status}`);
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}
