<template>
  <div>
    <nav class="nav" v-if="isAuth">
      <div class="nav-inner">
        <router-link to="/" class="nav-brand neon-sign">
          <span v-for="(char, i) in brandLetters" :key="i" class="neon-letter" :style="{ animationDelay: `${i * 0.08}s` }">{{ char }}</span>
        </router-link>
        <router-link to="/" class="nav-link" active-class="nav-link-active">ГЛАВНАЯ</router-link>
        <router-link to="/rooms" class="nav-link">ЗАЛЫ</router-link>
        <router-link to="/transport" class="nav-link">ТРАНСПОРТ</router-link>
        <router-link to="/bookings" class="nav-link">БРОНИРОВАНИЯ</router-link>
        <router-link to="/admin" v-if="isAdmin" class="nav-link nav-link-admin">АДМИН</router-link>
        <span class="user">{{ user?.fullName || user?.email }} <button type="button" class="btn btn-outline" @click="logout">Выйти</button></span>
      </div>
    </nav>
    <main :class="isHome ? 'main-full' : 'container main-light'">
      <router-view />
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
import { useRouter } from "vue-router";
import { isAuthenticated, getUser, clearTokens, setOnAuthChange } from "./api";

const router = useRouter();
const user = ref(getUser());
const isAuth = ref(isAuthenticated());

const isAdmin = computed(() => user.value?.role === "ADMIN");
const isHome = computed(() => router.currentRoute.value.path === "/");

const brandLetters = "CONFERENCE BOOKING".split("");

function logout() {
  clearTokens();
  router.push("/login");
}

onMounted(() => {
  setOnAuthChange(() => {
    user.value = getUser();
    isAuth.value = isAuthenticated();
  });
});
</script>
