<template>
  <div class="auth-page">
    <div class="auth-card">
      <h1>Вход</h1>
      <form @submit.prevent="submit">
        <div class="form-group">
          <label>Email</label>
          <input v-model="email" type="email" required />
        </div>
        <div class="form-group">
          <label>Пароль</label>
          <input v-model="password" type="password" required />
        </div>
        <p class="error" v-if="error">{{ error }}</p>
        <button type="submit" class="btn" :disabled="loading">Войти</button>
      </form>
      <p class="auth-footer">Нет аккаунта? <router-link to="/register">Регистрация</router-link></p>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import { apiJson, setTokens } from "../api";

const router = useRouter();
const email = ref("");
const password = ref("");
const error = ref("");
const loading = ref(false);

async function submit() {
  error.value = "";
  loading.value = true;
  try {
    const data = await apiJson("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email: email.value, password: password.value }),
    });
    setTokens(data.accessToken, data.refreshToken, data.user);
    router.push("/");
  } catch (e) {
    error.value = e.data?.error || e.message || "Ошибка входа";
  } finally {
    loading.value = false;
  }
}
</script>
