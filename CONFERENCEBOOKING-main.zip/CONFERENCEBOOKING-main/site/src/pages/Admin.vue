<template>
  <div>
    <h1 class="page-title">Админ-панель</h1>
    <div class="tabs">
      <button class="btn" :class="{ 'btn-secondary': tab !== 'rooms' }" @click="tab='rooms'">Залы</button>
      <button class="btn" :class="{ 'btn-secondary': tab !== 'transport' }" @click="tab='transport'">Транспорт</button>
      <button class="btn" :class="{ 'btn-secondary': tab !== 'users' }" @click="tab='users'">Пользователи</button>
    </div>

    <!-- Залы -->
    <section v-if="tab === 'rooms'">
      <h2 class="section-title">Залы</h2>
      <p v-if="roomsLoading" class="loading">Загрузка...</p>
      <template v-else>
        <div class="card" style="margin-bottom:1rem" v-if="showRoomForm">
          <h3>{{ editingRoom ? 'Редактировать зал' : 'Новый зал' }}</h3>
          <form @submit.prevent="saveRoom">
            <div class="form-group">
              <label>Название</label>
              <input v-model="roomForm.name" required />
            </div>
            <div class="form-group">
              <label>Адрес</label>
              <input v-model="roomForm.location" required />
            </div>
            <div class="form-group">
              <label>Вместимость</label>
              <input v-model.number="roomForm.capacity" type="number" min="1" required />
            </div>
            <div class="form-group">
              <label>Описание</label>
              <textarea v-model="roomForm.description" rows="2"></textarea>
            </div>
            <div class="form-group">
              <label>Цена за час (₽)</label>
              <input v-model.number="roomForm.pricePerHour" type="number" min="0" />
            </div>
            <div class="form-group">
              <label>Теги (через запятую)</label>
              <input v-model="roomForm.tagsStr" type="text" placeholder="тренинг, корпоратив, презентация" />
            </div>
            <div class="form-group">
              <label>Ссылки на изображения (по одной в строке)</label>
              <textarea v-model="roomForm.imageUrlsStr" rows="3" placeholder="https://..."></textarea>
            </div>
            <button type="submit" class="btn">{{ editingRoom ? 'Обновить зал' : 'Сохранить' }}</button>
            <button type="button" class="btn btn-secondary" @click="showRoomForm = false; editingRoom = null" style="margin-left:0.5rem">Отмена</button>
          </form>
        </div>
        <button v-else class="btn" @click="openNewRoom">Добавить зал</button>
        <p class="hint">Двойной клик по залу открывает форму редактирования.</p>
        <div class="grid" style="margin-top:1rem">
          <div v-for="r in rooms" :key="r.id" class="card admin-card" @dblclick="editRoom(r)">
            <h4 style="margin:0 0 0.5rem">{{ r.name }}</h4>
            <p style="margin:0 0 0.25rem; font-size:0.9rem">{{ r.location }}, {{ r.capacity }} чел.</p>
            <button class="btn btn-secondary" style="margin-right:0.5rem; margin-top:0.5rem" @click.stop="editRoom(r)">Изменить</button>
            <button class="btn btn-danger" style="margin-top:0.5rem" @click.stop="deleteRoom(r.id)">Удалить</button>
          </div>
        </div>
      </template>
    </section>

    <!-- Транспорт -->
    <section v-if="tab === 'transport'">
      <h2 class="section-title">Транспорт</h2>
      <p v-if="transportLoading" class="loading">Загрузка...</p>
      <template v-else>
        <div class="card" style="margin-bottom:1rem" v-if="showTransportForm">
          <h3>{{ editingTransport ? 'Редактировать' : 'Новый транспорт' }}</h3>
          <form @submit.prevent="saveTransport">
            <div class="form-group">
              <label>Название</label>
              <input v-model="transportForm.name" required />
            </div>
            <div class="form-group">
              <label>Тип</label>
              <input v-model="transportForm.type" required />
            </div>
            <div class="form-group">
              <label>Мест</label>
              <input v-model.number="transportForm.seats" type="number" min="1" required />
            </div>
            <div class="form-group">
              <label>Цена (₽/час)</label>
              <input v-model.number="transportForm.pricePerHour" type="number" min="0" placeholder="По запросу — оставьте пустым" />
            </div>
            <div class="form-group">
              <label>Описание</label>
              <textarea v-model="transportForm.description" rows="2"></textarea>
            </div>
            <div class="form-group">
              <label>Ссылки на изображения (по одной в строке)</label>
              <textarea v-model="transportForm.imageUrlsStr" rows="3" placeholder="https://..."></textarea>
            </div>
            <button type="submit" class="btn">Сохранить</button>
            <button type="button" class="btn btn-secondary" @click="showTransportForm = false; editingTransport = null" style="margin-left:0.5rem">Отмена</button>
          </form>
        </div>
        <button v-else class="btn" @click="openNewTransport">Добавить транспорт</button>
        <p class="hint">Двойной клик по транспорту открывает форму редактирования.</p>
        <div class="grid" style="margin-top:1rem">
          <div v-for="t in transportList" :key="t.id" class="card admin-card" @dblclick="editTransport(t)">
            <h4 style="margin:0 0 0.5rem">{{ t.name }}</h4>
            <p style="margin:0 0 0.25rem; font-size:0.9rem">{{ t.type }}, мест: {{ t.seats }}{{ t.pricePerHour != null ? ' · ' + t.pricePerHour.toLocaleString('ru-RU') + ' ₽/час' : '' }}</p>
            <button class="btn btn-secondary" style="margin-right:0.5rem; margin-top:0.5rem" @click.stop="editTransport(t)">Изменить</button>
            <button class="btn btn-danger" style="margin-top:0.5rem" @click.stop="deleteTransport(t.id)">Удалить</button>
          </div>
        </div>
      </template>
    </section>

    <!-- Пользователи -->
    <section v-if="tab === 'users'">
      <h2 class="section-title">Пользователи</h2>
      <p v-if="usersLoading" class="loading">Загрузка...</p>
      <div v-else class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Email</th>
              <th>Имя</th>
              <th>Роль</th>
              <th>Действия</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="u in users" :key="u.id">
              <td>{{ u.email }}</td>
              <td>{{ u.fullName }}</td>
              <td>
                <select :value="u.role" @change="changeRole(u.id, $event.target.value)" :disabled="u.id === currentUserId">
                  <option value="USER">USER</option>
                  <option value="ADMIN">ADMIN</option>
                </select>
              </td>
              <td>
                <button class="btn btn-danger" style="padding:0.25rem 0.5rem; font-size:0.8rem" @click="deleteUser(u.id)" :disabled="u.id === currentUserId">Удалить</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from "vue";
import { api, apiJson } from "../api";
import { getUser } from "../api";

const tab = ref("rooms");
const rooms = ref([]);
const roomsLoading = ref(false);
const showRoomForm = ref(false);
const editingRoom = ref(null);
const roomForm = ref({ name: "", location: "", capacity: 20, description: "", pricePerHour: "", tagsStr: "", imageUrlsStr: "" });

const transportList = ref([]);
const transportLoading = ref(false);
const showTransportForm = ref(false);
const editingTransport = ref(null);
const transportForm = ref({ name: "", type: "", seats: 10, description: "", pricePerHour: "", imageUrlsStr: "" });

const users = ref([]);
const usersLoading = ref(false);
const currentUserId = ref(getUser()?.id);

async function loadRooms() {
  roomsLoading.value = true;
  try {
    const res = await api("/rooms");
    if (res.ok) rooms.value = await res.json();
  } finally {
    roomsLoading.value = false;
  }
}

async function loadTransport() {
  transportLoading.value = true;
  try {
    const res = await api("/transport");
    if (res.ok) transportList.value = await res.json();
  } finally {
    transportLoading.value = false;
  }
}

async function loadUsers() {
  usersLoading.value = true;
  try {
    const res = await api("/admin/users");
    if (res.ok) users.value = await res.json();
  } finally {
    usersLoading.value = false;
  }
}

function openNewRoom() {
  editingRoom.value = null;
  roomForm.value = { name: "", location: "", capacity: 20, description: "", pricePerHour: "", tagsStr: "", imageUrlsStr: "" };
  showRoomForm.value = true;
}

function editRoom(r) {
  editingRoom.value = r;
  roomForm.value = {
    name: r.name,
    location: r.location,
    capacity: r.capacity,
    description: r.description || "",
    pricePerHour: r.pricePerHour ?? "",
    tagsStr: (r.tags || []).join(", "),
    imageUrlsStr: (r.imageUrls || []).join("\n"),
  };
  showRoomForm.value = true;
}

async function saveRoom() {
  try {
    const payload = {
      name: roomForm.value.name,
      location: roomForm.value.location,
      capacity: roomForm.value.capacity,
      description: roomForm.value.description || null,
      pricePerHour: roomForm.value.pricePerHour !== "" ? Number(roomForm.value.pricePerHour) : null,
      tags: roomForm.value.tagsStr ? roomForm.value.tagsStr.split(",").map((s) => s.trim()).filter(Boolean) : [],
      imageUrls: roomForm.value.imageUrlsStr ? roomForm.value.imageUrlsStr.split(/\r?\n/).map((s) => s.trim()).filter(Boolean) : [],
    };
    if (editingRoom.value) {
      await apiJson(`/rooms/${editingRoom.value.id}`, { method: "PUT", body: JSON.stringify(payload) });
    } else {
      await apiJson("/rooms", { method: "POST", body: JSON.stringify(payload) });
    }
    showRoomForm.value = false;
    editingRoom.value = null;
    loadRooms();
  } catch (e) {
    alert(e.data?.error || e.message);
  }
}

async function deleteRoom(id) {
  if (!confirm("Удалить зал?")) return;
  try {
    const res = await api(`/rooms/${id}`, { method: "DELETE" });
    if (res.ok) loadRooms();
    else alert("Ошибка удаления");
  } catch (e) {
    alert(e.message);
  }
}

function openNewTransport() {
  editingTransport.value = null;
  transportForm.value = { name: "", type: "", seats: 10, description: "", pricePerHour: "", imageUrlsStr: "" };
  showTransportForm.value = true;
}

function editTransport(t) {
  editingTransport.value = t;
  transportForm.value = {
    name: t.name,
    type: t.type,
    seats: t.seats,
    description: t.description || "",
    pricePerHour: t.pricePerHour ?? "",
    imageUrlsStr: (t.imageUrls || []).join("\n"),
  };
  showTransportForm.value = true;
}

async function saveTransport() {
  try {
    const payload = {
      name: transportForm.value.name,
      type: transportForm.value.type,
      seats: transportForm.value.seats,
      description: transportForm.value.description || null,
      pricePerHour:
        transportForm.value.pricePerHour !== "" &&
        transportForm.value.pricePerHour != null
          ? Number(transportForm.value.pricePerHour)
          : null,
      imageUrls: transportForm.value.imageUrlsStr
        ? transportForm.value.imageUrlsStr
            .split(/\r?\n/)
            .map((s) => s.trim())
            .filter(Boolean)
        : [],
    };
    if (editingTransport.value) {
      await apiJson(`/transport/${editingTransport.value.id}`, { method: "PUT", body: JSON.stringify(payload) });
    } else {
      await apiJson("/transport", { method: "POST", body: JSON.stringify(payload) });
    }
    showTransportForm.value = false;
    editingTransport.value = null;
    loadTransport();
  } catch (e) {
    alert(e.data?.error || e.message);
  }
}

async function deleteTransport(id) {
  if (!confirm("Удалить транспорт?")) return;
  try {
    const res = await api(`/transport/${id}`, { method: "DELETE" });
    if (res.ok) loadTransport();
    else alert("Ошибка удаления");
  } catch (e) {
    alert(e.message);
  }
}

async function changeRole(userId, role) {
  try {
    await apiJson(`/admin/users/${userId}`, { method: "PATCH", body: JSON.stringify({ role }) });
    loadUsers();
  } catch (e) {
    alert(e.data?.error || e.message);
  }
}

async function deleteUser(id) {
  if (!confirm("Удалить пользователя?")) return;
  try {
    const res = await api(`/admin/users/${id}`, { method: "DELETE" });
    if (res.ok) loadUsers();
    else alert("Ошибка удаления");
  } catch (e) {
    alert(e.data?.error || e.message);
  }
}

watch(tab, (t) => {
  if (t === "rooms") loadRooms();
  else if (t === "transport") loadTransport();
  else if (t === "users") loadUsers();
});

onMounted(() => {
  if (tab.value === "rooms") loadRooms();
  else if (tab.value === "transport") loadTransport();
  else loadUsers();
});
</script>
