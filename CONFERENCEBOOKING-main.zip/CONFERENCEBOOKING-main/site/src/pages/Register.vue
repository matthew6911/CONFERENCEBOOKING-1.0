<template>
  <div class="auth-page">
    <div class="auth-card">
      <h1>Регистрация</h1>
      <form @submit.prevent="submit">
        <div class="form-group">
          <label>ФИО</label>
          <input v-model="fullName" type="text" required minlength="2" />
        </div>
        <div class="form-group">
          <label>Email</label>
          <input v-model="email" type="email" required />
        </div>
        <div class="form-group">
          <label>Пароль (не менее 6 символов)</label>
          <input v-model="password" type="password" required minlength="6" />
        </div>
        <div class="form-group">
          <label>Код приглашения администратора (необязательно)</label>
          <input v-model="inviteAdminCode" type="text" placeholder="ADMIN-INVITE-2026" />
        </div>
        <div class="form-group captcha-group">
          <label>Подтверждение: {{ captchaA }} + {{ captchaB }} = ?</label>
          <input v-model.number="captchaAnswer" type="number" placeholder="Ответ" required />
        </div>
        <p class="error" v-if="error">{{ error }}</p>
        <button type="submit" class="btn" :disabled="loading">Зарегистрироваться</button>
      </form>
      <p class="auth-footer">Уже есть аккаунт? <router-link to="/login">Вход</router-link></p>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRouter } from "vue-router";
import { apiJson, setTokens } from "../api";

const router = useRouter();
const fullName = ref("");
const email = ref("");
const password = ref("");
const inviteAdminCode = ref("");
const error = ref("");
const loading = ref(false);
const captchaA = ref(0);
const captchaB = ref(0);
const captchaAnswer = ref("");

function newCaptcha() {
  captchaA.value = Math.floor(Math.random() * 9) + 1;
  captchaB.value = Math.floor(Math.random() * 9) + 1;
  captchaAnswer.value = "";
}

onMounted(newCaptcha);

async function submit() {
  error.value = "";
  if (Number(captchaAnswer.value) !== captchaA.value + captchaB.value) {
    error.value = "Неверный ответ на вопрос. Попробуйте снова.";
    newCaptcha();
    return;
  }
  loading.value = true;
  try {
    const body = { fullName: fullName.value, email: email.value, password: password.value };
    if (inviteAdminCode.value.trim()) body.inviteAdminCode = inviteAdminCode.value.trim();
    const data = await apiJson("/auth/register", {
      method: "POST",
      body: JSON.stringify(body),
    });
    setTokens(data.accessToken, data.refreshToken, data.user);
    router.push("/");
  } catch (e) {
    error.value = e.data?.error || e.message || "Ошибка регистрации";
    newCaptcha();
  } finally {
    loading.value = false;
  }
}
</script>
