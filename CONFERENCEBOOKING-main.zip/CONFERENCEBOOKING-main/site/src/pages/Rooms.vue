<template>
  <div>
    <h1 class="page-title">Залы</h1>
    <p v-if="loading" class="loading">Загрузка...</p>
    <p v-else-if="error" class="error">{{ error }}</p>
    <div class="grid grid-2" v-else>
      <div
        v-for="room in rooms"
        :key="room.id"
        class="card card-room"
        @dblclick="openModal(room)"
      >
        <div class="carousel">
          <button type="button" class="carousel-btn carousel-prev" @click.stop="prevSlide(room.id)" aria-label="Назад">‹</button>
          <img
            v-for="(url, i) in getRoomImages(room)"
            v-show="getCurrentIndex(room.id) === i"
            :key="i"
            :src="url"
            alt=""
            class="card-image"
          />
          <div v-if="!getRoomImages(room).length" class="card-image card-image-placeholder">Нет фото</div>
          <button type="button" class="carousel-btn carousel-next" @click.stop="nextSlide(room.id)" aria-label="Вперёд">›</button>
          <div class="carousel-dots">
            <button
              v-for="(_, i) in getRoomImages(room)"
              :key="i"
              type="button"
              class="carousel-dot"
              :class="{ active: getCurrentIndex(room.id) === i }"
              @click.stop="setSlide(room.id, i)"
            />
          </div>
        </div>
        <h3 class="card-title">{{ room.name }}</h3>
        <p class="card-meta">{{ room.location }}</p>
        <p class="card-meta">Вместимость: {{ room.capacity }} чел.</p>
        <p class="card-meta card-price">{{ room.pricePerHour != null ? room.pricePerHour.toLocaleString('ru-RU') + ' ₽/час' : 'По запросу' }}</p>
        <p v-if="room.tags?.length" class="card-tags">
          <span v-for="tag in room.tags" :key="tag" class="tag">{{ tag }}</span>
        </p>
        <p v-if="room.description" class="card-desc">{{ room.description }}</p>
        <div class="btn-group">
          <button type="button" class="btn" @click.stop="openModal(room)">Подробнее</button>
        </div>
      </div>
    </div>

    <!-- Модальное окно зала -->
    <div v-if="modalRoom" class="modal-overlay" @click.self="modalRoom = null">
      <div class="modal">
        <button type="button" class="modal-close" @click="modalRoom = null" aria-label="Закрыть">×</button>
        <div class="modal-carousel">
          <button type="button" class="carousel-btn carousel-prev" @click="prevModalSlide">‹</button>
          <img
            v-for="(url, i) in getRoomImages(modalRoom)"
            v-show="modalSlideIndex === i"
            :key="i"
            :src="url"
            alt=""
            class="modal-image"
          />
          <div v-if="!getRoomImages(modalRoom).length" class="modal-image modal-image-placeholder">Нет фото</div>
          <button type="button" class="carousel-btn carousel-next" @click="nextModalSlide">›</button>
          <div class="carousel-dots">
            <button
              v-for="(_, i) in getRoomImages(modalRoom)"
              :key="i"
              type="button"
              class="carousel-dot"
              :class="{ active: modalSlideIndex === i }"
              @click="modalSlideIndex = i"
            />
          </div>
        </div>
        <h2 class="section-title">{{ modalRoom.name }}</h2>
        <p class="card-meta">{{ modalRoom.location }} · {{ modalRoom.capacity }} чел.</p>
        <p class="card-meta card-price">
          {{ modalRoom.pricePerHour != null ? modalRoom.pricePerHour.toLocaleString('ru-RU') + ' ₽/час' : 'По запросу' }}
        </p>
        <p v-if="modalRoom.tags?.length" class="card-tags">
          <span v-for="tag in modalRoom.tags" :key="tag" class="tag">{{ tag }}</span>
        </p>
        <p v-if="modalRoom.description" class="card-desc">{{ modalRoom.description }}</p>
        <form @submit.prevent="createBookingFromModal" class="modal-form">
          <div class="form-group">
            <label>Название мероприятия</label>
            <input v-model="modalForm.title" required />
          </div>
          <div class="form-group">
            <label>Начало</label>
            <input v-model="modalForm.startTime" type="datetime-local" required />
          </div>
          <div class="form-group">
            <label>Окончание</label>
            <input v-model="modalForm.endTime" type="datetime-local" required />
          </div>
          <p
            v-if="modalRoom.pricePerHour != null && modalForm.startTime && modalForm.endTime"
            class="card-meta card-price"
          >
            Стоимость: {{ formatPrice(calcRoomCost(modalRoom, modalForm.startTime, modalForm.endTime)) }}
          </p>
          <div class="form-group">
            <label>Участников</label>
            <input v-model.number="modalForm.attendees" type="number" min="1" :max="modalRoom.capacity" required />
          </div>
          <p class="error" v-if="modalBookingError">{{ modalBookingError }}</p>
          <button type="submit" class="btn" :disabled="bookingLoading">Забронировать зал</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
import { api, apiJson } from "../api";

const rooms = ref([]);
const loading = ref(true);
const error = ref("");
const bookingLoading = ref(false);

const modalRoom = ref(null);
const modalSlideIndex = ref(0);
const modalForm = ref({ title: "", startTime: "", endTime: "", attendees: 1 });
const modalBookingError = ref("");

const slideIndex = ref({});

const minDateTime = computed(() => {
  const d = new Date();
  // Округляем вниз до целого часа, без странных минут
  d.setMinutes(0, 0, 0);
  return d.toISOString().slice(0, 16);
});

function calcHours(startStr, endStr) {
  const start = new Date(startStr);
  const end = new Date(endStr);
  const diff = end.getTime() - start.getTime();
  if (!isFinite(diff) || diff <= 0) return 0;
  const hours = diff / (1000 * 60 * 60);
  return Math.max(1, Math.ceil(hours));
}

function calcRoomCost(room, startStr, endStr) {
  if (!room || room.pricePerHour == null) return 0;
  const hours = calcHours(startStr, endStr);
  return hours * Number(room.pricePerHour || 0);
}

function formatPrice(amount) {
  if (!amount) return "0 ₽";
  return Number(amount).toLocaleString("ru-RU") + " ₽";
}

function getRoomImages(room) {
  const urls = [];
  if (room?.id != null) {
    // Локальные картинки из папки public/images/rooms
    urls.push(
      `/images/rooms/room-${room.id}-1.jpg`,
      `/images/rooms/room-${room.id}-2.jpg`,
      `/images/rooms/room-${room.id}-3.jpg`
    );
  }
  if (room.imageUrls && room.imageUrls.length) {
    urls.push(...room.imageUrls);
  }
  if (!urls.length) {
    urls.push(
      "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=80"
    );
  }
  // Оставляем максимум 3
  return urls.slice(0, 3);
}

function getCurrentIndex(roomId) {
  const idx = slideIndex.value[roomId] ?? 0;
  return Math.min(idx, 2);
}

function prevSlide(roomId) {
  const n = slideIndex.value[roomId] ?? 0;
  slideIndex.value = { ...slideIndex.value, [roomId]: n <= 0 ? 2 : n - 1 };
}

function nextSlide(roomId) {
  const n = slideIndex.value[roomId] ?? 0;
  slideIndex.value = { ...slideIndex.value, [roomId]: n >= 2 ? 0 : n + 1 };
}

function setSlide(roomId, i) {
  slideIndex.value = { ...slideIndex.value, [roomId]: i };
}

function openModal(room) {
  modalRoom.value = room;
  modalSlideIndex.value = 0;
  modalForm.value = { title: "", startTime: "", endTime: "", attendees: Math.min(10, room.capacity) };
  modalBookingError.value = "";
}

function prevModalSlide() {
  const imgs = getRoomImages(modalRoom.value);
  modalSlideIndex.value = modalSlideIndex.value <= 0 ? imgs.length - 1 : modalSlideIndex.value - 1;
}

function nextModalSlide() {
  const imgs = getRoomImages(modalRoom.value);
  modalSlideIndex.value = modalSlideIndex.value >= imgs.length - 1 ? 0 : modalSlideIndex.value + 1;
}

async function createBookingFromModal() {
  if (!modalRoom.value) return;
  modalBookingError.value = "";
  const start = new Date(modalForm.value.startTime);
  const end = new Date(modalForm.value.endTime);
  if (end <= start) {
    modalBookingError.value = "Время окончания должно быть позже времени начала.";
    return;
  }
  if (start < new Date()) {
    modalBookingError.value = "Нельзя бронировать на прошедшее время.";
    return;
  }
  bookingLoading.value = true;
  try {
    await apiJson("/bookings/rooms", {
      method: "POST",
      body: JSON.stringify({
        roomId: Number(modalRoom.value.id),
        title: String(modalForm.value.title).trim(),
        startTime: String(modalForm.value.startTime),
        endTime: String(modalForm.value.endTime),
        attendees: Number(modalForm.value.attendees),
      }),
    });
    modalRoom.value = null;
  } catch (e) {
    modalBookingError.value = e.data?.error || e.message || "Не удалось создать бронирование.";
  } finally {
    bookingLoading.value = false;
  }
}

async function loadRooms() {
  loading.value = true;
  error.value = "";
  try {
    const res = await api("/rooms");
    if (!res.ok) throw new Error("Не удалось загрузить залы");
    rooms.value = await res.json();
  } catch (e) {
    error.value = e.message || "Ошибка";
  } finally {
    loading.value = false;
  }
}

onMounted(loadRooms);
</script>
