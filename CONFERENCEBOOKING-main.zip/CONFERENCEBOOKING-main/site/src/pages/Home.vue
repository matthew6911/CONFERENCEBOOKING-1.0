<template>
  <div class="home-light">
    <!-- Hero: BRON SPACE AGENCY -->
    <section class="hero-bron">
      <div class="hero-bron-inner">
        <h1 class="hero-bron-title neon-hero">
          <span v-for="(char, i) in heroLetters" :key="i" class="neon-hero-letter" :class="{ 'neon-hero-space': char === ' ' }" :style="{ animationDelay: `${i * 0.06}s` }">{{ char === ' ' ? '\u00A0' : char }}</span>
        </h1>
        <div class="hero-bron-grid">
          <div class="hero-bron-text">
            <p>Мы объединяем бронирование конференц-залов, транспорта и логистики в одном интерфейсе, чтобы организация бизнес-мероприятий стала проще и прозрачнее.</p>
            <p>От презентаций автомобилей до корпоративных тренингов — мы лично проверяем площадки и транспорт и помогаем подобрать оптимальный вариант под ваш сценарий.</p>
          </div>
          <div class="hero-bron-lists">
            <h3 class="hero-bron-list-title">Форматы, с которыми мы работаем</h3>
            <ul>
              <li>Презентации автомобилей и продуктов</li>
              <li>Стратегические и обучающие сессии</li>
              <li>Корпоративные встречи и тимбилдинги</li>
            </ul>
            <h3 class="hero-bron-list-title">Что даёт платформа</h3>
            <ul>
              <li>Единый каталог залов и транспорта</li>
              <li>Онлайновое бронирование и личный кабинет</li>
              <li>Прозрачные условия и сценарии «под ключ»</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA -->
    <section class="section-dark cta-section">
      <div class="content-wrap">
        <h2 class="section-dark-title">Подберите зал и трансфер под ваш сценарий</h2>
        <p>Укажите тип мероприятия, количество гостей и желаемые даты — мы подберём подходящие залы и транспорт. Бронирование онлайн, без лишних звонков.</p>
        <p>Все площадки и машины проверены: вы видите актуальные фото, описание и условия. После бронирования остаётся только приехать на мероприятие.</p>
        <div class="cta-buttons">
          <router-link to="/rooms" class="btn btn-primary-dark">Смотреть залы</router-link>
          <router-link to="/transport" class="btn btn-dark-secondary">Смотреть транспорт</router-link>
          <router-link to="/bookings" class="btn btn-dark-secondary">Мои бронирования</router-link>
        </div>
      </div>
    </section>

    <!-- Как мы работаем -->
    <section class="section-dark">
      <div class="content-wrap">
        <h2 class="section-dark-title">КАК МЫ РАБОТАЕМ</h2>
        <p class="section-dark-intro">Четыре шага от заявки до проведения мероприятия: вы заполняете параметры, выбираете варианты из каталога, бронируете онлайн, а в день мероприятия мы координируем всё необходимое.</p>
        <div class="steps-grid">
          <div class="step-block">
            <span class="step-num">01.</span>
            <h3 class="step-title">БРИФ</h3>
            <p>Вы указываете тип события, количество гостей, даты и пожелания. Мы подбираем залы и транспорт под ваш сценарий.</p>
          </div>
          <div class="step-block">
            <span class="step-num">02.</span>
            <h3 class="step-title">ВЫБОР</h3>
            <p>Просматриваете каталог залов и транспорта с фото и описаниями. Фильтры по вместимости и типу события помогают сузить выбор.</p>
          </div>
          <div class="step-block">
            <span class="step-num">03.</span>
            <h3 class="step-title">БРОНИРОВАНИЕ</h3>
            <p>Оформляете бронь онлайн в личном кабинете. Указываете время, участников и при необходимости транспорт — всё в одном месте.</p>
          </div>
          <div class="step-block">
            <span class="step-num">04.</span>
            <h3 class="step-title">МЕРОПРИЯТИЕ</h3>
            <p>В день события координация на нашей стороне: зал и транспорт готовы, вы занимаетесь только содержанием мероприятия.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Визуальная галерея -->
    <section class="section-dark">
      <div class="content-wrap">
        <h2 class="section-dark-title">ВИЗУАЛЬНАЯ ГАЛЕРЕЯ</h2>
        <p class="section-dark-intro">Фотографии залов и транспорта из каталога: LOFT «Авиатор», Skyline, «Невский», Workshop Hub и другие. Слайд-шоу формируется из загруженных в проект изображений.</p>
        <div class="gallery-carousel">
          <button type="button" class="carousel-btn-dark carousel-prev" @click="prevPhoto" aria-label="Назад">‹</button>
          <img
            v-for="(url, i) in galleryPhotos"
            v-show="photoIndex === i"
            :key="i"
            :src="url"
            alt=""
            class="gallery-image"
          />
          <div v-if="!galleryPhotos.length" class="gallery-placeholder">
            Слайд-шоу появится автоматически после добавления фотографий в проект.
          </div>
          <button type="button" class="carousel-btn-dark carousel-next" @click="nextPhoto" aria-label="Вперёд">›</button>
          <div class="carousel-dots carousel-dots-dark">
            <button v-for="(_, i) in galleryPhotos" :key="i" type="button" class="carousel-dot" :class="{ active: photoIndex === i }" @click="photoIndex = i" />
          </div>
        </div>
      </div>
    </section>

    <!-- Отзывы клиентов -->
    <section class="section-dark">
      <div class="content-wrap">
        <h2 class="section-dark-title">ОТЗЫВЫ КЛИЕНТОВ</h2>
        <p class="section-dark-intro">
          Короткие живые отзывы клиентов: один за другим, в формате карусели.
        </p>
        <div class="testimonial-card">
          <p class="testimonial-name">{{ currentReview.name }}</p>
          <p class="testimonial-role">{{ currentReview.role }}</p>
          <p class="testimonial-text">{{ currentReview.text }}</p>
        </div>
        <div class="testimonial-footer">
          <span class="testimonial-pagination">Отзыв {{ reviewIndex + 1 }} из {{ reviews.length }}</span>
          <div class="testimonial-arrows">
            <button type="button" class="btn-circle" @click="prevReview" aria-label="Назад">←</button>
            <button type="button" class="btn-circle" @click="nextReview" aria-label="Вперёд">→</button>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from "vue";
import { api } from "../api";

const heroLetters = "BRON SPACE AGENCY".split("");

const photoIndex = ref(0);
const reviewIndex = ref(0);

const heroPhotos = [
  // LOFT "Авиатор" (id 1)
  "/images/rooms/room-1-1.jpg",
  "/images/rooms/room-1-2.jpg",
  "/images/rooms/room-1-3.jpg",
  // Конференц-зал Skyline (id 2)
  "/images/rooms/room-2-1.jpg",
  "/images/rooms/room-2-2.jpg",
  "/images/rooms/room-2-3.jpg",
  // Бизнес-зал "Невский" (id 3)
  "/images/rooms/room-3-1.jpg",
  "/images/rooms/room-3-2.jpg",
  "/images/rooms/room-3-3.jpg",
  // Workshop Hub (id 4)
  "/images/rooms/room-4-1.jpg",
  "/images/rooms/room-4-2.jpg",
  "/images/rooms/room-4-3.jpg",
  // Event Hall Atrium (id 5)
  "/images/rooms/room-5-1.jpg",
  "/images/rooms/room-5-2.jpg",
  "/images/rooms/room-5-3.jpg",
  // Studio Stage (id 6)
  "/images/rooms/room-6-1.jpg",
  "/images/rooms/room-6-2.jpg",
  "/images/rooms/room-6-3.jpg",
  // Press Center (id 7)
  "/images/rooms/room-7-1.jpg",
  "/images/rooms/room-7-2.jpg",
  "/images/rooms/room-7-3.jpg",
  // Boardroom Prime (id 8)
  "/images/rooms/room-8-1.jpg",
  "/images/rooms/room-8-2.jpg",
  "/images/rooms/room-8-3.jpg",
];

const reviews = [
  { name: "Анна Петрова", role: "HR директор, Яндекс", text: "Удобно бронировать залы и транспорт в одном месте. Площадки соответствуют описанию, координация в день мероприятия — на высоте." },
  { name: "Дмитрий Кузнецов", role: "Организатор мероприятий", text: "Пользовались для презентации продукта и тимбилдинга. Подобрали зал и трансфер под гостей — всё прошло без сюрпризов." },
  { name: "Елена Соколова", role: "Маркетинг, IT‑стартап", text: "Единый каталог и онлайн-бронирование экономят время. Не надо обзванивать площадки, всё в одном интерфейсе." },
  { name: "Сергей Волков", role: "Ивент-менеджер", text: "Работаем с BRON уже не первый раз. Залы в Москве и Питере проверенные, транспорт приезжает вовремя." },
  { name: "Ольга Морозова", role: "Директор по развитию", text: "Используем для стратегических сессий и обучающих программ. Зал, трансфер и тайминг — всё под ключ." },
  { name: "Игорь Афанасьев", role: "Руководитель отдела продаж", text: "Проводили большую конференцию для партнёров. Удобно, что можно сразу забронировать и зал, и шаттлы от отеля." },
  { name: "Мария Белова", role: "HR бизнес-партнёр", text: "Для тимбилдинга подобрали лофт и автобус. Все участники отметили удобство логистики и саму площадку." },
  { name: "Павел Романов", role: "Ивент-агентство", text: "Платформу используем как базу проверенных площадок. Быстро подбираем варианты под бриф клиента." },
  { name: "Ксения Литвинова", role: "PR‑менеджер", text: "Делали презентацию автомобиля. Важно было сочетание зала и парковки — подошёл первый предложенный вариант." },
  { name: "Алексей Григорьев", role: "Операционный директор", text: "Нравится прозрачный расчёт по часам: сразу видим стоимость зала и трансфера, без скрытых доплат." },
  { name: "Наталья Орлова", role: "Event & Communications", text: "Для серии воркшопов забронировали несколько залов через BRON. Удобно копировать параметры и быстро повторять сценарий." },
  { name: "Роман Чернов", role: "Руководитель проектов", text: "Личный кабинет с бронированиями и оплатами сильно упрощает отчётность и согласование бюджета." },
  { name: "Виктория Смирнова", role: "Executive assistant", text: "Когда нужно срочно собрать встречу топ-менеджмента, просто открываю BRON и выбираю подходящий зал за пару минут." },
];

const galleryPhotos = ref([...heroPhotos]);

let photoTimer = null;
let reviewTimer = null;

const currentReview = computed(() => reviews[reviewIndex.value]);

function nextPhoto() {
  if (!galleryPhotos.value.length) return;
  photoIndex.value = (photoIndex.value + 1) % galleryPhotos.value.length;
  resetPhotoTimer();
}
function prevPhoto() {
  if (!galleryPhotos.value.length) return;
  photoIndex.value = photoIndex.value <= 0 ? galleryPhotos.value.length - 1 : photoIndex.value - 1;
  resetPhotoTimer();
}
function resetPhotoTimer() {
  if (photoTimer) clearInterval(photoTimer);
  if (galleryPhotos.value.length) photoTimer = setInterval(nextPhoto, 5000);
}

function nextReview() {
  reviewIndex.value = (reviewIndex.value + 1) % reviews.length;
  resetReviewTimer();
}

function prevReview() {
  reviewIndex.value = reviewIndex.value <= 0 ? reviews.length - 1 : reviewIndex.value - 1;
  resetReviewTimer();
}

function resetReviewTimer() {
  if (reviewTimer) clearInterval(reviewTimer);
  reviewTimer = setInterval(nextReview, 6000);
}
onMounted(() => {
  if (galleryPhotos.value.length) photoTimer = setInterval(nextPhoto, 5000);
  reviewTimer = setInterval(nextReview, 6000);
});

onUnmounted(() => {
  if (photoTimer) clearInterval(photoTimer);
  if (reviewTimer) clearInterval(reviewTimer);
});
</script>
