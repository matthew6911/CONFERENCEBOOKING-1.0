<template>
  <div>
    <h1 class="page-title">Транспорт</h1>
    <p v-if="loading" class="loading">Загрузка...</p>
    <p v-else-if="error" class="error">{{ error }}</p>
    <div class="grid grid-2" v-else>
      <div
        v-for="t in transport"
        :key="t.id"
        class="card card-room"
        @dblclick="openModal(t)"
      >
        <div class="carousel">
          <img
            :src="getTransportImage(t)"
            alt=""
            class="card-image card-image-transport"
          />
          <div
            v-if="!getTransportImage(t)"
            class="card-image card-image-placeholder"
          >
            Нет фото
          </div>
        </div>
        <h3 class="card-title">{{ t.name }}</h3>
        <p class="card-meta">{{ t.type }}</p>
        <p class="card-meta">Мест: {{ t.seats }}</p>
        <p class="card-meta card-price">
          {{
            t.pricePerHour != null
              ? t.pricePerHour.toLocaleString("ru-RU") + " ₽/час"
              : "По запросу"
          }}
        </p>
        <p v-if="t.description" class="card-desc">{{ t.description }}</p>
        <div class="btn-group">
          <button
            type="button"
            class="btn"
            @click.stop="openModal(t)"
          >
            Забронировать
          </button>
        </div>
      </div>
    </div>

    <!-- Модальное окно транспорта -->
    <div
      v-if="modalTransport"
      class="modal-overlay"
      @click.self="modalTransport = null"
    >
      <div class="modal">
        <button
          type="button"
          class="modal-close"
          @click="modalTransport = null"
          aria-label="Закрыть"
        >
          ×
        </button>
        <div class="modal-carousel">
          <img
            :src="getTransportImage(modalTransport)"
            alt=""
            class="modal-image modal-image-transport"
          />
          <div
            v-if="!getTransportImage(modalTransport)"
            class="modal-image modal-image-placeholder"
          >
            Нет фото
          </div>
        </div>
        <h2 class="section-title">{{ modalTransport.name }}</h2>
        <p class="card-meta">
          {{ modalTransport.type }} · мест: {{ modalTransport.seats }}
        </p>
        <p class="card-meta card-price">
          {{
            modalTransport.pricePerHour != null
              ? modalTransport.pricePerHour.toLocaleString("ru-RU") +
                " ₽/час"
              : "По запросу"
          }}
        </p>
        <p v-if="modalTransport.description" class="card-desc">
          {{ modalTransport.description }}
        </p>
        <form @submit.prevent="createTransportBookingFromModal" class="modal-form">
          <div class="form-group">
            <label>Начало поездки</label>
            <input
              v-model="modalForm.startTime"
              type="datetime-local"
              required
            />
          </div>
          <div class="form-group">
            <label>Окончание поездки</label>
            <input
              v-model="modalForm.endTime"
              type="datetime-local"
              required
            />
          </div>
          <div class="form-group">
            <label>Количество мест</label>
            <input
              v-model.number="modalForm.seatsBooked"
              type="number"
              min="1"
              :max="modalTransport.seats"
              required
            />
          </div>
          <p
            v-if="modalTransport.pricePerHour != null && modalForm.startTime && modalForm.endTime"
            class="card-meta card-price"
          >
            Стоимость: {{ formatPrice(calcTransportCost(modalTransport, modalForm.startTime, modalForm.endTime)) }}
          </p>
          <p class="error" v-if="modalBookingError">{{ modalBookingError }}</p>
          <button
            type="submit"
            class="btn"
            :disabled="bookingLoading"
          >
            Забронировать транспорт
          </button>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
import { api, apiJson } from "../api";

const transport = ref([]);
const loading = ref(true);
const error = ref("");
const bookingLoading = ref(false);

const modalTransport = ref(null);
const modalForm = ref({ startTime: "", endTime: "", seatsBooked: 1 });
const modalBookingError = ref("");

const minDateTime = computed(() => {
  const d = new Date();
  // Округляем вниз до целого часа, без странных минут
  d.setMinutes(0, 0, 0);
  return d.toISOString().slice(0, 16);
});

function calcHours(startStr, endStr) {
  const start = new Date(startStr);
  const end = new Date(endStr);
  const diff = end.getTime() - start.getTime();
  if (!isFinite(diff) || diff <= 0) return 0;
  const hours = diff / (1000 * 60 * 60);
  return Math.max(1, Math.ceil(hours));
}

function calcTransportCost(item, startStr, endStr) {
  if (!item || item.pricePerHour == null) return 0;
  const hours = calcHours(startStr, endStr);
  return hours * Number(item.pricePerHour || 0);
}

function formatPrice(amount) {
  if (!amount) return "0 ₽";
  return Number(amount).toLocaleString("ru-RU") + " ₽";
}

function getTransportImage(item) {
  if (!item) return "";
  const url =
    item.imageUrls && item.imageUrls.length
      ? item.imageUrls[0]
      : `/images/transport/transport-${item.id}.jpg`;
  return url;
}

function openModal(item) {
  modalTransport.value = item;
  modalForm.value = {
    startTime: "",
    endTime: "",
    seatsBooked: Math.min(5, item.seats),
  };
  modalBookingError.value = "";
}

async function createTransportBookingFromModal() {
  if (!modalTransport.value) return;
  modalBookingError.value = "";
  const start = new Date(modalForm.value.startTime);
  const end = new Date(modalForm.value.endTime);
  if (end <= start) {
    modalBookingError.value =
      "Время окончания должно быть позже времени начала.";
    return;
  }
  if (start < new Date()) {
    modalBookingError.value = "Нельзя бронировать на прошедшее время.";
    return;
  }
  bookingLoading.value = true;
  try {
    await apiJson("/bookings/transport", {
      method: "POST",
      body: JSON.stringify({
        transportId: Number(modalTransport.value.id),
        startTime: String(modalForm.value.startTime),
        endTime: String(modalForm.value.endTime),
        seatsBooked: Number(modalForm.value.seatsBooked),
      }),
    });
    modalTransport.value = null;
  } catch (e) {
    modalBookingError.value =
      e.data?.error || e.message || "Не удалось создать бронирование.";
  } finally {
    bookingLoading.value = false;
  }
}

async function loadTransport() {
  loading.value = true;
  error.value = "";
  try {
    const res = await api("/transport");
    if (!res.ok) throw new Error("Не удалось загрузить транспорт");
    transport.value = await res.json();
  } catch (e) {
    error.value = e.message || "Ошибка";
  } finally {
    loading.value = false;
  }
}

onMounted(loadTransport);
</script>

