<template>
  <div>
    <h1 class="page-title">Мои бронирования</h1>
    <p v-if="loading" class="loading">Загрузка...</p>
    <p v-else-if="error" class="error">{{ error }}</p>
    <template v-else>
      <div v-if="toastMessage" class="toast" :class="toastType">
        {{ toastMessage }}
      </div>

      <div class="card" style="margin-bottom:1rem">
        <h2 class="section-title" style="margin-top:0">Итог по бронированиям</h2>
        <p class="card-meta">Всего: {{ formatPrice(totalCostAll) }}</p>
        <p class="card-meta">Оплачено: {{ formatPrice(totalCostPaid) }}</p>
        <p class="card-meta">Не оплачено: {{ formatPrice(totalCostUnpaid) }}</p>
      </div>

      <h2 class="section-title">Залы — не оплачено</h2>
      <div v-if="!roomUnpaid.length" class="empty-state">Нет неоплаченных бронирований залов.</div>
      <div v-else class="grid">
        <div v-for="b in roomUnpaid" :key="'ru'+b.id" class="card">
          <h3 class="card-title">{{ b.title }}</h3>
          <p class="card-meta">{{ b.room?.name }}</p>
          <p class="card-desc">
            {{ formatDate(b.startTime) }} – {{ formatDate(b.endTime) }}, участников: {{ b.attendees }}
          </p>
          <p
            v-if="b.room?.pricePerHour != null"
            class="card-meta card-price"
          >
            Стоимость: {{ formatPrice(calcRoomBookingCost(b)) }}
          </p>
          <div class="btn-group">
            <button type="button" class="btn btn-success" @click="markPaid('room', b)">Оплатить</button>
            <button type="button" class="btn btn-danger" @click="cancelRoom(b.id)">Отменить</button>
          </div>
        </div>
      </div>

      <h2 class="section-title">Залы — оплачено</h2>
      <div v-if="!roomPaid.length" class="empty-state">Нет оплаченных бронирований залов.</div>
      <div v-else class="grid">
        <div v-for="b in roomPaid" :key="'rp'+b.id" class="card">
          <h3 class="card-title">{{ b.title }}</h3>
          <p class="card-meta">{{ b.room?.name }}</p>
          <p class="card-desc">
            {{ formatDate(b.startTime) }} – {{ formatDate(b.endTime) }}, участников: {{ b.attendees }}
          </p>
          <p
            v-if="b.room?.pricePerHour != null"
            class="card-meta card-price"
          >
            Стоимость: {{ formatPrice(calcRoomBookingCost(b)) }}
          </p>
          <p class="card-meta" style="color:var(--success)">Статус: оплачено</p>
          <div class="btn-group">
            <button type="button" class="btn btn-danger" @click="cancelRoom(b.id)">Отменить</button>
          </div>
        </div>
      </div>

      <h2 class="section-title">Транспорт — не оплачено</h2>
      <div v-if="!transportUnpaid.length" class="empty-state">Нет неоплаченных бронирований транспорта.</div>
      <div v-else class="grid">
        <div v-for="b in transportUnpaid" :key="'tu'+b.id" class="card">
          <h3 class="card-title">{{ b.transport?.name }}</h3>
          <p class="card-meta">Мест: {{ b.seatsBooked }}</p>
          <p class="card-desc">
            {{ formatDate(b.startTime) }} – {{ formatDate(b.endTime) }}
          </p>
          <p
            v-if="b.transport?.pricePerHour != null"
            class="card-meta card-price"
          >
            Стоимость: {{ formatPrice(calcTransportBookingCost(b)) }}
          </p>
          <div class="btn-group">
            <button type="button" class="btn btn-success" @click="markPaid('transport', b)">Оплатить</button>
            <button type="button" class="btn btn-danger" @click="cancelTransport(b.id)">Отменить</button>
          </div>
        </div>
      </div>

      <h2 class="section-title">Транспорт — оплачено</h2>
      <div v-if="!transportPaid.length" class="empty-state">Нет оплаченных бронирований транспорта.</div>
      <div v-else class="grid">
        <div v-for="b in transportPaid" :key="'tp'+b.id" class="card">
          <h3 class="card-title">{{ b.transport?.name }}</h3>
          <p class="card-meta">Мест: {{ b.seatsBooked }}</p>
          <p class="card-desc">
            {{ formatDate(b.startTime) }} – {{ formatDate(b.endTime) }}
          </p>
          <p
            v-if="b.transport?.pricePerHour != null"
            class="card-meta card-price"
          >
            Стоимость: {{ formatPrice(calcTransportBookingCost(b)) }}
          </p>
          <p class="card-meta" style="color:var(--success)">Статус: оплачено</p>
          <div class="btn-group">
            <button type="button" class="btn btn-danger" @click="cancelTransport(b.id)">Отменить</button>
          </div>
        </div>
      </div>
    </template>

    <!-- Модалка оплаты -->
    <div v-if="payModal" class="modal-overlay" @click.self="payModal = null">
      <div class="modal modal-sm">
        <h3 class="section-title">Оплата выполнена</h3>
        <p>{{ payModalText }}</p>
        <button type="button" class="btn" @click="payModal = null">Готово</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from "vue";
import { api } from "../api";

const bookings = ref({ roomBookings: [], transportBookings: [] });
const loading = ref(true);
const error = ref("");
const toastMessage = ref("");
const toastType = ref("success");
const payModal = ref(null);
const payModalText = ref("");

function formatDate(s) {
  if (!s) return "";
  const d = new Date(s);
  return d.toLocaleString("ru-RU");
}

function calcHours(startStr, endStr) {
  const start = new Date(startStr);
  const end = new Date(endStr);
  const diff = end.getTime() - start.getTime();
  if (!isFinite(diff) || diff <= 0) return 0;
  const hours = diff / (1000 * 60 * 60);
  return Math.max(1, Math.ceil(hours));
}

function calcRoomBookingCost(b) {
  if (!b.room || b.room.pricePerHour == null) return 0;
  const hours = calcHours(b.startTime, b.endTime);
  return hours * Number(b.room.pricePerHour || 0);
}

function calcTransportBookingCost(b) {
  if (!b.transport || b.transport.pricePerHour == null) return 0;
  const hours = calcHours(b.startTime, b.endTime);
  return hours * Number(b.transport.pricePerHour || 0);
}

function formatPrice(amount) {
  if (!amount) return "0 ₽";
  return Number(amount).toLocaleString("ru-RU") + " ₽";
}

const roomUnpaid = computed(() =>
  (bookings.value.roomBookings || []).filter((b) => !b.isPaid)
);
const roomPaid = computed(() =>
  (bookings.value.roomBookings || []).filter((b) => b.isPaid)
);
const transportUnpaid = computed(() =>
  (bookings.value.transportBookings || []).filter((b) => !b.isPaid)
);
const transportPaid = computed(() =>
  (bookings.value.transportBookings || []).filter((b) => b.isPaid)
);

const totalCostAll = computed(() => {
  const rooms = (bookings.value.roomBookings || []).reduce(
    (sum, b) => sum + calcRoomBookingCost(b),
    0
  );
  const transport = (bookings.value.transportBookings || []).reduce(
    (sum, b) => sum + calcTransportBookingCost(b),
    0
  );
  return rooms + transport;
});

const totalCostPaid = computed(() => {
  const rooms = roomPaid.value.reduce(
    (sum, b) => sum + calcRoomBookingCost(b),
    0
  );
  const transport = transportPaid.value.reduce(
    (sum, b) => sum + calcTransportBookingCost(b),
    0
  );
  return rooms + transport;
});

const totalCostUnpaid = computed(() => totalCostAll.value - totalCostPaid.value);

function showToast(msg, type = "success") {
  toastMessage.value = msg;
  toastType.value = type;
  setTimeout(() => { toastMessage.value = ""; }, 4000);
}

function markPaid(kind, b) {
  if (kind === "room") {
    bookings.value = {
      ...bookings.value,
      roomBookings: (bookings.value.roomBookings || []).map((x) =>
        x.id === b.id ? { ...x, isPaid: true } : x
      ),
    };
    showPayModal(kind, b);
  } else {
    bookings.value = {
      ...bookings.value,
      transportBookings: (bookings.value.transportBookings || []).map((x) =>
        x.id === b.id ? { ...x, isPaid: true } : x
      ),
    };
    showPayModal(kind, b);
  }
}

function showPayModal(kind, b) {
  if (kind === "room") {
    payModalText.value = `Оплата за бронирование зала «${b.room?.name || b.title}» проведена.`;
  } else {
    payModalText.value = `Оплата за бронирование транспорта «${b.transport?.name}» проведена.`;
  }
  payModal.value = true;
}

async function load() {
  loading.value = true;
  error.value = "";
  try {
    const res = await api("/bookings/me");
    if (!res.ok) throw new Error("Не удалось загрузить бронирования");
    const raw = await res.json();
    bookings.value = {
      roomBookings: (raw.roomBookings || []).map((b) => ({ ...b, isPaid: false })),
      transportBookings: (raw.transportBookings || []).map((b) => ({
        ...b,
        isPaid: false,
      })),
    };
  } catch (e) {
    error.value = e.message || "Ошибка";
  } finally {
    loading.value = false;
  }
}

async function cancelRoom(id) {
  const list = bookings.value.roomBookings || [];
  bookings.value = { ...bookings.value, roomBookings: list.filter((b) => b.id !== id) };
  try {
    const res = await api(`/bookings/rooms/${id}`, { method: "DELETE" });
    if (res.ok) {
      showToast("Бронирование зала отменено.", "success");
    } else {
      const data = await res.json().catch(() => ({}));
      showToast(data.error || "Не удалось отменить.", "error");
      load();
    }
  } catch (e) {
    showToast(e.data?.error || e.message || "Ошибка отмены", "error");
    load();
  }
}

async function cancelTransport(id) {
  const list = bookings.value.transportBookings || [];
  bookings.value = { ...bookings.value, transportBookings: list.filter((b) => b.id !== id) };
  try {
    const res = await api(`/bookings/transport/${id}`, { method: "DELETE" });
    if (res.ok) {
      showToast("Бронирование транспорта отменено.", "success");
    } else {
      const data = await res.json().catch(() => ({}));
      showToast(data.error || "Не удалось отменить.", "error");
      load();
    }
  } catch (e) {
    showToast(e.data?.error || e.message || "Ошибка отмены", "error");
    load();
  }
}

onMounted(load);
</script>
