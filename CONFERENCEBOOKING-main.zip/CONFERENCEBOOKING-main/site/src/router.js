import { createRouter, createWebHistory } from "vue-router";
import { isAuthenticated, getUser } from "./api";
import Login from "./pages/Login.vue";
import Register from "./pages/Register.vue";
import Home from "./pages/Home.vue";
import Rooms from "./pages/Rooms.vue";
import Transport from "./pages/Transport.vue";
import MyBookings from "./pages/MyBookings.vue";
import Admin from "./pages/Admin.vue";

const routes = [
  { path: "/", component: Home, meta: { requiresAuth: true } },
  { path: "/login", component: Login, meta: { guest: true } },
  { path: "/register", component: Register, meta: { guest: true } },
  { path: "/rooms", component: Rooms, meta: { requiresAuth: true } },
  { path: "/transport", component: Transport, meta: { requiresAuth: true } },
  { path: "/bookings", component: MyBookings, meta: { requiresAuth: true } },
  { path: "/admin", component: Admin, meta: { requiresAuth: true, admin: true } },
];

const router = createRouter({ history: createWebHistory(), routes });

router.beforeEach((to, _from, next) => {
  const auth = isAuthenticated();
  const user = getUser();
  if (to.meta.requiresAuth && !auth) return next("/login");
  if (to.meta.admin && user?.role !== "ADMIN") return next("/");
  if (to.meta.guest && auth) return next("/");
  next();
});

export default router;
